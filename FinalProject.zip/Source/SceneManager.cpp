///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// Indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// Try to parse the image data from the specified image file
	unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

	if (image)
	{
		std::cout << "Successfully loaded image: " << filename
			<< ", width: " << width
			<< ", height: " << height
			<< ", channels: " << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// Set texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		// Set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (colorChannels == 3)
		{
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		}
		else if (colorChannels == 4)
		{
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		}
		else
		{
			std::cerr << "Unsupported number of channels: " << colorChannels << std::endl;
			stbi_image_free(image);
			return false;
		}

		// Generate texture mipmaps
		glGenerateMipmap(GL_TEXTURE_2D);
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);

		// Register the texture
		for (int i = 0; i < m_loadedTextures; i++)
		{
			if (m_textureIDs[i].tag == tag)
			{
				std::cerr << "Warning: Duplicate texture tag \"" << tag << "\" detected. Skipping registration." << std::endl;
				return true;
			}
		}

		if (m_loadedTextures >= 16)
		{
			std::cerr << "Error: Exceeded maximum texture slots (16)." << std::endl;
			return false;
		}

		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;

		std::cout << "Registered texture tag: " << tag
			<< " at slot: " << m_loadedTextures << std::endl;

		m_loadedTextures++;
		return true;
	}

	std::cerr << "Failed to load image: " << filename << std::endl;
	return false;
}


/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].tag == tag)
		{
			return i; // Return the slot without logging
		}
	}
	return -1; // Return -1 if not found
}




/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureSlot = FindTextureSlot(textureTag);
		if (textureSlot >= 0)
		{
			glActiveTexture(GL_TEXTURE0 + textureSlot); // Activate the texture unit
			glBindTexture(GL_TEXTURE_2D, m_textureIDs[textureSlot].ID); // Bind the texture
			m_pShaderManager->setSampler2DValue(g_TextureValueName, textureSlot); // Pass to shader
		}
		else
		{
			std::cout << "Texture not found: " << textureTag << std::endl;
		}
	}
}


/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load necessary meshes
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();

	// Load textures
	//Will print message if unable to load the images
	if (!CreateGLTexture("textures/marble.jpg", "TableTexture"))
	{
		std::cerr << "Failed to load TableTexture" << std::endl;
	}

	if (!CreateGLTexture("textures/wood.jpg", "LegTexture"))
	{
		std::cerr << "Failed to load LegTexture" << std::endl;
	}

	if (!CreateGLTexture("textures/swirl.jpg", "CupTexture"))
	{
		std::cerr << "Failed to load CupTexture" << std::endl;
	}

	if (!CreateGLTexture("textures/black.jpg", "KBTexture"))
	{
		std::cerr << "Failed to load KBTexture" << std::endl;
	}

	if (!CreateGLTexture("textures/static.jpg", "MonitorTexture"))
	{
		std::cerr << "Failed to load MonitorTexture" << std::endl;
	}

	if (!CreateGLTexture("textures/basecolor.jpg", "BaseTexture"))
	{
		std::cerr << "Failed to load BaseTexture" << std::endl;
	}

	if (!CreateGLTexture("textures/mesh.jpg", "MeshTexture"))
	{
		std::cerr << "Failed to load MeshTexture" << std::endl;
	}

	// Define a shiny brown material
	OBJECT_MATERIAL brownMaterial;
	brownMaterial.tag = "brown";
	brownMaterial.diffuseColor = glm::vec3(0.6f, 0.3f, 0.1f);  // Brown
	brownMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);  // White specular
	brownMaterial.shininess = 2.0f;  // Low shininess
	m_objectMaterials.push_back(brownMaterial);

	/* UNUSUED
	// Define a shiny blue material
	OBJECT_MATERIAL blueMaterial;
	blueMaterial.tag = "blue";
	blueMaterial.diffuseColor = glm::vec3(0.0f, 0.0f, 1.0f);  // Blue
	blueMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);  // White specular
	blueMaterial.shininess = 32.0f;  // High shininess
	m_objectMaterials.push_back(blueMaterial);
	*/

	// Define a shiny grey material
	OBJECT_MATERIAL greyMaterial;
	greyMaterial.tag = "grey";
	greyMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);  // Grey
	greyMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);  // White specular
	greyMaterial.shininess = 15.0f;  // Medium shininess
	m_objectMaterials.push_back(greyMaterial);

	OBJECT_MATERIAL cyanMaterial;
	cyanMaterial.tag = "cyan";
	cyanMaterial.diffuseColor = glm::vec3(0.0f, 1.0f, 1.0f);  // Grey
	cyanMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);  // White specular
	cyanMaterial.shininess = 15.0f;  // Medium shininess
	m_objectMaterials.push_back(cyanMaterial);



	// Enable custom lighting in the shader
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Directional Light (white)
	glm::vec3 lightDirection1 = glm::vec3(1.0f, -1.0f, -1.0f);  // Light direction
	m_pShaderManager->setVec3Value("directionalLight.direction", lightDirection1);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(1.0f, 1.0f, 1.0f));  // White
	m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(1.0f, 1.0f, 1.0f));
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// Point Light (cyan light)
	glm::vec3 lightPosition2 = glm::vec3(-5.0f, 5.0f, -5.0f);
	m_pShaderManager->setVec3Value("pointLights[0].position", lightPosition2);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.0f, 1.0f, 1.0f));  // Cyan
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(1.0f, 1.0f, 1.0f));
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// Set up camera position (view position)
	glm::vec3 viewPosition = glm::vec3(0.0f, 0.0f, 5.0f);  // Adjust this based on your camera position
	m_pShaderManager->setVec3Value("viewPosition", viewPosition);

}


/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;
	float XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f;

	// ** Render Table Top (Box) **
	scaleXYZ = glm::vec3(6.0f, 0.2f, 2.5f);
	positionXYZ = glm::vec3(0.0f, 2.5f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	//Applies marble texture to the table top
	//Will print message to confirm application successful
	//std::cout << "Applying TableTexture to Box" << std::endl;
	SetShaderTexture("TableTexture");
	SetShaderMaterial("grey");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// ** Render Table Legs (Cylinders) **
	glm::vec3 legPositions[] = {
		glm::vec3(-1.7f, 1.0f, -0.9f),
		glm::vec3(1.7f, 1.0f, -0.9f),
		glm::vec3(-1.7f, 1.0f, 0.9f),
		glm::vec3(1.7f, 1.0f, 0.9f)
	};

	for (int i = 0; i < 4; ++i)
	{
		scaleXYZ = glm::vec3(0.2f, 1.5f, 0.2f);
		positionXYZ = legPositions[i];
		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		//Apply wood texture to the legs
		//Will print message to confirm application successful
		//std::cout << "Applying LegTexture to Cylinder " << i + 1 << std::endl;
		SetShaderTexture("LegTexture");
		SetShaderMaterial("brown");
		SetTextureUVScale(1.0f, 1.0f);
		m_basicMeshes->DrawCylinderMesh();

		// ** Render Monitor (Screen) **
		scaleXYZ = glm::vec3(3.0f, 1.55f, 0.1f); // Screen size
		positionXYZ = glm::vec3(0.0f, 3.5f, -0.9f); // Above table and slightly back
		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		SetShaderTexture("MonitorTexture");
		SetShaderMaterial("grey");
		SetTextureUVScale(1.0f, 1.0f);
		m_basicMeshes->DrawBoxMesh();

		// ** Render Monitor Stand **
		scaleXYZ = glm::vec3(0.2f, 1.0f, 0.2f); // Stand size
		positionXYZ = glm::vec3(0.0f, 3.0f, -1.0f); // Below the screen
		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		SetShaderTexture("BaseTexture");
		//SetShaderMaterial("grey");
		m_basicMeshes->DrawBoxMesh();

		// Render Monitor Base
		scaleXYZ = glm::vec3(0.5f, 0.1f, 0.4f); // Base size
		positionXYZ = glm::vec3(0.0f, 2.6f, -1.0f); // Slightly below the stand
		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		SetShaderTexture("BaseTexture");
		//SetShaderMaterial("grey");
		m_basicMeshes->DrawBoxMesh();

		// Render Cylinder (Speaker)
		glm::vec3 scaleOuter = glm::vec3(0.3f, 0.5f, 0.3f); // Outer size
		//glm::vec3 scaleInner = glm::vec3(0.28f, 0.5f, 0.28f); // Inner size (slightly smaller)
		glm::vec3 positionCup = glm::vec3(2.8f, 2.6f, -0.9f); // Position on the table

		// Render Outer Cylinder
		SetTransformations(scaleOuter, 0.0f, 0.0f, 0.0f, positionCup);
		SetShaderTexture("MeshTexture");
		//SetShaderMaterial("brown"); // Exterior material
		m_basicMeshes->DrawCylinderMesh();


		// Render Keyboard Base
		scaleXYZ = glm::vec3(2.0f, 0.1f, 0.5f); // Keyboard base size
		positionXYZ = glm::vec3(0.0f, 2.6f, 0.8f); // Position on the table
		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		SetShaderTexture("KBTexture");
		SetShaderMaterial("grey");
		m_basicMeshes->DrawBoxMesh();

		// Render Keys (Aligned with Keyboard Base)
		float keyboardWidth = 2.0f;  // Width of the keyboard base
		float keyboardDepth = 0.5f;  // Depth of the keyboard base
		float keySize = 0.05f;       // Size of each key
		float spacingX = keyboardWidth / 10.0f; // Spacing between keys in X direction
		float spacingZ = keyboardDepth / 5.0f; // Spacing between keys in Z direction

		int keysPerRow = 10; // Number of keys in each row
		int numRows = 5;     // Number of rows of keys

		// Start positions relative to the keyboard base
		float startX = -keyboardWidth / 2.0f + spacingX / 2.0f; // Center keys in X
		float startZ = -keyboardDepth / 2.0f + spacingZ / 2.0f; // Center keys in Z
		float keyboardY = 2.6f + 0.05f; // Slightly above the keyboard base

		for (int row = 0; row < numRows; ++row)
		{
			for (int col = 0; col < keysPerRow; ++col)
			{
				glm::vec3 scaleXYZ = glm::vec3(keySize, keySize, keySize); // Key size
				glm::vec3 positionXYZ = glm::vec3(
					startX + col * spacingX,  // Spread keys along X
					keyboardY,                // Align with keyboard base height
					0.8f + startZ + row * spacingZ // Spread keys along Z relative to the keyboard base
				);

				SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
				SetShaderTexture("TableTexture");
				//SetShaderMaterial("cyan"); // Keys are black
				m_basicMeshes->DrawBoxMesh();
			}
		}
	}
}